library(testthat)
library(lambda.r)
library(lambda.tools)
test_package('lambda.tools')
