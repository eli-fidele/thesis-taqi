library(testit)
test_pkg('futile.matrix')

